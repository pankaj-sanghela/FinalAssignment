package Pages;

import Common.Predefined;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class Signup extends  CommonPage{
    public Signup(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver,this);
    }
    @FindBy(xpath = "//button[@type='submit']")
    WebElement SignupButton;
    @FindBy(xpath = "//a[contains(@class,'theme-btn theme-btn-small waves-effect')]")
    WebElement SignUpMenuButton;
    @FindBy(xpath = "//input[@placeholder='First Name']")
    WebElement Firstname;
    @FindBy(xpath = "//input[@placeholder='Last Name']")
    WebElement Lastname;
    @FindBy(xpath = "//input[@placeholder='Phone']")
    WebElement Phone;
    @FindBy(xpath = "//button[@type='submit']")
    WebElement MainSignupButton;
public void SignupDetails() {

       // driver.findElement(By.xpath("//a[contains(@class,'theme-btn theme-btn-small waves-effect')]")).click();
     SignUpMenuButton.click();
    Predefined.holdExecutionForSeconds(3);
       // Assert.assertTrue(Predefined.isDisplayedElement("//div[@class='header-top-bar padding-right-100px padding-left-100px']//div[@class='row align-items-center']"));
       // driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys("prachi");
    Firstname.sendKeys("pankaj");
    Predefined.holdExecutionForSeconds(3);
      //  driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys("manjhi");
       Lastname.sendKeys("sanghela");
        Predefined.holdExecutionForSeconds(3);
       // driver.findElement(By.xpath("//input[@placeholder='Phone']")).sendKeys("1234567890");
    Phone.sendKeys("9599366935");
    Predefined.holdExecutionForSeconds(3);
        //driver.findElement(By.xpath("//input[@placeholder='Email']")).sendKeys("manjhi@gmail.com");
    Email.sendKeys("pankajsanghela@gmail.com");
    Predefined.holdExecutionForSeconds(3);
       // driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys("12345");
    Password.sendKeys("12345");
    Predefined.holdExecutionForSeconds(3);
        driver.findElement(By.xpath("//span[@role='combobox']"));
        Predefined.holdExecutionForSeconds(3);
       // driver.findElement(By.xpath("//button[@class='cc-btn cc-dismiss waves-effect']")).click();
    Cookie.click();
    Predefined.holdExecutionForSeconds(2);
        //driver.findElement(By.xpath("//button[@type='submit']")).click();
    MainSignupButton.click();
    Predefined.holdExecutionForSeconds(3);


    }
}
