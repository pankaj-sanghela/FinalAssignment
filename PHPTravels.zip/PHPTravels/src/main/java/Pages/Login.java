package Pages;

import Common.Predefined;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class Login extends CommonPage {
    public Login(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver,this);
    }
//    @FindBy(xpath = "//a[@class='theme-btn theme-btn-small theme-btn-transparent ml-1 waves-effect']")
//    WebElement LoginMenuButton;
//    @FindBy(xpath = "//input[@placeholder='Email']")
//    WebElement EmailInput;
//    @FindBy(xpath = "//input[@placeholder='Password']")
//    WebElement PasswordInput;
//    @FindBy(xpath = "//button[@class='cc-btn cc-dismiss waves-effect']")
//    WebElement Cookie;
//    @FindBy(xpath = "//button[@class='btn btn-default btn-lg btn-block effect ladda-button waves-effect']")
//    WebElement MainLoginButton;

    public void LoginFunction()
    {

        LoginMenuButton.click();
        Predefined.holdExecutionForSeconds(3);

        Email.click();
        Email.sendKeys(CommonPage.properties.getProperty("email"));
        Predefined.holdExecutionForSeconds(3);

        Password.sendKeys("Pankaj123@");
        Predefined.holdExecutionForSeconds(3);

      //  Cookie.click();

        MainLoginButton.click();
        Predefined.holdExecutionForSeconds(3);

    }
    }

